import React, { useState } from 'react';

function HospitalForm({ onSubmit }) {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('');
  const [department, setDepartment] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ name, age, gender, department });
  };

  return (
    <div className="container">
      <h1>Hastane Kayıt Formu</h1>
      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <label>İsim:</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div className="input-group">
          <label>Yaş:</label>
          <input type="number" value={age} onChange={(e) => setAge(e.target.value)} required />
        </div>
        <div className="input-group">
          <label>Cinsiyet:</label>
          <select value={gender} onChange={(e) => setGender(e.target.value)} required>
            <option value="">Seçiniz</option>
            <option value="male">Erkek</option>
            <option value="female">Kadın</option>
            <option value="other">Diğer</option>
          </select>
        </div>
        <div className="input-group">
          <label>Bölüm:</label>
          <input type="text" value={department} onChange={(e) => setDepartment(e.target.value)} required />
        </div>
        <button type="submit">Kaydet</button>
      </form>
    </div>
  );
}

export default HospitalForm;
