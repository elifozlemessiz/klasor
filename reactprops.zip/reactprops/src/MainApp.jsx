import React from 'react';
import './App.css';
import HospitalForm from './hospitalForm';

function MainApp() {
  const handleSubmit = (formData) => {
    console.log('Gönderilen veriler:', formData);
  };

  return (
    <div>
      <HospitalForm onSubmit={handleSubmit} />
    </div>
  );
}

export default MainApp;
